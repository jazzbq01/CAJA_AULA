import {BrowserRouter,Routes,Route} from "react-router-dom"
import Layout from "./layout/Layout.jsx"
import Dashboard from "./pages/Dashboard.jsx"
import Alumnos from "./pages/Alumnos.jsx"
import AlumnoDetalle from "./pages/AlumnoDetalle.jsx"
import Reportes from "./pages/Reportes.jsx"

export default function App(){
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard/>}/>
          <Route path="/alumnos" element={<Alumnos/>}/>
          <Route path="/alumnos/:id" element={<AlumnoDetalle/>}/>
          <Route path="/reportes" element={<Reportes/>}/>
        </Routes>
      </Layout>
    </BrowserRouter>
  )
}
