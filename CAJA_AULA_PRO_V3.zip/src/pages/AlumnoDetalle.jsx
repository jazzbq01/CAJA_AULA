import { useEffect, useState } from "react"
import { useParams } from "react-router-dom"
import { supabase } from "../lib/supabase"

export default function AlumnoDetalle() {
  const { id } = useParams()

  const [mov, setMov] = useState([])
  const [saldo, setSaldo] = useState(null)

  useEffect(() => {
    load()
  }, [])

  const load = async () => {

    const { data: saldoData } = await supabase
      .from("saldos")
      .select("*")
      .eq("alumno_id", id)
      .single()

    const { data: movData } = await supabase
      .from("movimientos")
      .select("*")
      .eq("alumno_id", id)
      .order("created_at", { ascending: true })

    setSaldo(saldoData)
    setMov(movData || [])
  }

  const ingresos = mov.filter(m => m.tipo === "INGRESO").reduce((a, b) => a + b.monto, 0)
  const gastos = mov.filter(m => m.tipo === "GASTO").reduce((a, b) => a + b.monto, 0)

  const print = () => window.print()

  return (
    <div>

      <h1>📄 Estado de Cuenta</h1>

      {saldo && (
        <div style={{
          background: "white",
          padding: 15,
          borderRadius: 8,
          marginBottom: 20
        }}>
          <p>💰 Saldo inicial: S/ {saldo.saldo_inicial}</p>
          <p>📈 Ingresos: S/ {ingresos}</p>
          <p>📉 Gastos: S/ {gastos}</p>

          <h2>🟢 Saldo actual: S/ {saldo.saldo_actual}</h2>

          <button onClick={print}>🖨 Imprimir</button>
        </div>
      )}

      <h3>📜 Historial</h3>

      {mov.map(m => (
        <div key={m.id} style={{
          background: "white",
          padding: 10,
          marginBottom: 5,
          borderLeft: m.tipo === "INGRESO" ? "5px solid green" : "5px solid red"
        }}>
          {m.concepto} - {m.tipo} - S/ {m.monto}
        </div>
      ))}

    </div>
  )
}