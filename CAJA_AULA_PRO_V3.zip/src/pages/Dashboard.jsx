import { useEffect, useState } from "react"
import { supabase } from "../lib/supabase"

export default function Dashboard() {

  const [total, setTotal] = useState(0)

  useEffect(() => {
    load()
  }, [])

  const load = async () => {
    const { data } = await supabase.from("saldos").select("*")

    const suma = (data || []).reduce(
      (a, b) => a + (b.saldo_actual || 0),
      0
    )

    setTotal(suma)
  }

  return (
    <div>
      <h1>📊 Dashboard</h1>

      <div style={{
        background: "white",
        padding: 20,
        borderRadius: 10
      }}>
        <h2>Total Aula</h2>
        <h1>💰 S/ {total}</h1>
      </div>
    </div>
  )
}