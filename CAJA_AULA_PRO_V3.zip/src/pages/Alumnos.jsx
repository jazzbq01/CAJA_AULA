import { useEffect, useState } from "react"
import { supabase } from "../lib/supabase"
import { Link } from "react-router-dom"

export default function Alumnos() {
  const [alumnos, setAlumnos] = useState([])
  const [nombre, setNombre] = useState("")
  const [saldo, setSaldo] = useState(0)

  // 🔥 CARGA ALUMNOS + SALDO
  const load = async () => {
    const { data } = await supabase
      .from("alumnos")
      .select(`
        id,
        nombre,
        saldos (
          saldo_inicial,
          saldo_actual
        )
      `)

    setAlumnos(data || [])
  }

  useEffect(() => {
    load()
  }, [])

  // ➕ CREAR ALUMNO + SALDO INICIAL
  const crear = async () => {
    if (!nombre) return

    const { data } = await supabase
      .from("alumnos")
      .insert([{ nombre }])
      .select()

    const a = data?.[0]

    if (a) {
      await supabase.from("saldos").insert([
        {
          alumno_id: a.id,
          saldo_inicial: Number(saldo),
          saldo_actual: Number(saldo),
        },
      ])
    }

    setNombre("")
    setSaldo(0)
    load()
  }

  const addSaldo = async (id) => {
  const monto = prompt("Monto adicional")

  if (!monto) return

  await supabase.from("movimientos").insert([
    {
      alumno_id: id,
      tipo: "INGRESO",
      concepto: "Saldo adicional",
      monto: Number(monto)
    }
  ])

  load()
}

  return (
    <div>
      <h1>Alumnos</h1>

      {/* FORM CREAR */}
      <div style={{ marginBottom: 15 }}>
        <input
          placeholder="Nombre alumno"
          value={nombre}
          onChange={(e) => setNombre(e.target.value)}
        />

        <input
          placeholder="Saldo inicial"
          type="number"
          value={saldo}
          onChange={(e) => setSaldo(e.target.value)}
          style={{ marginLeft: 10 }}
        />

        <button onClick={crear} style={{ marginLeft: 10 }}>
          Crear
        </button>
      </div>

      {/* LISTA */}
      {alumnos.map((a) => {
        const s = a.saldos?.[0]

        return (
          <div
            key={a.id}
            style={{
              background: "#fff",
              margin: 8,
              padding: 12,
              borderRadius: 6,
              boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
            }}
          >
            <Link to={`/alumnos/${a.id}`}>
              <b>{a.nombre}</b>
            </Link>
            <button onClick={() => addSaldo(a.id)}>
              Agregar saldo
            </button>
            {/* 💰 SALDOS VISIBLES */}
            <div style={{ marginTop: 6 }}>
              💰 Inicial: S/ {s?.saldo_inicial ?? 0}
            </div>

            <div>
              📉 Actual: S/ {s?.saldo_actual ?? 0}
            </div>

            <div>
              📊 Restante: S/ {s?.saldo_actual ?? 0}
            </div>
          </div>
        )
      })}
    </div>
  )
}