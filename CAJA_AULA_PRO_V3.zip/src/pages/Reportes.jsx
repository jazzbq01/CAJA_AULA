import { useEffect,useState } from "react"
import { supabase } from "../lib/supabase"

export default function Reportes(){
  const [alumnos,setAlumnos]=useState([])

  useEffect(()=>{load()},[])

  const load=async()=>{
    const {data}=await supabase.from("alumnos").select("*")
    setAlumnos(data||[])
  }

  const printAlumno = (id)=>{
    window.open(`/alumnos/${id}`,"_blank")
  }

  return (
    <div>
      <h1>Reportes</h1>

      {alumnos.map(a=>(
        <div key={a.id} style={{background:"#fff",margin:5,padding:10}}>
          {a.nombre}
          <button onClick={()=>printAlumno(a.id)}>Ver / Imprimir</button>
        </div>
      ))}
    </div>
  )
}
