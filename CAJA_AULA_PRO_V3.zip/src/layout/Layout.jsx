import { Link } from "react-router-dom"

export default function Layout({ children }) {
  return (
    <div style={{ display: "flex", minHeight: "100vh", fontFamily: "Arial" }}>

      {/* SIDEBAR MODERNO */}
      <aside style={{
        width: 240,
        background: "#0f172a",
        color: "white",
        padding: 20
      }}>
        <h2>💰 Caja Aula</h2>

        <nav style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 20 }}>
          <Link style={{ color: "white" }} to="/">📊 Dashboard</Link>
          <Link style={{ color: "white" }} to="/alumnos">👨‍🎓 Alumnos</Link>
          <Link style={{ color: "white" }} to="/reportes">🧾 Reportes</Link>
        </nav>
      </aside>

      {/* CONTENIDO */}
      <main style={{ flex: 1, padding: 20, background: "#f1f5f9" }}>
        {children}
      </main>

    </div>
  )
}